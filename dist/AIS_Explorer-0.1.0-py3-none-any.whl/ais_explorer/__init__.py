from ais_explorer import AIS, Exceptions

__version__ = '0.1.0'